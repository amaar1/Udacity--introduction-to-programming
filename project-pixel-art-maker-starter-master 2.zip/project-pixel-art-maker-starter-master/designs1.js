// Select color input
var color
var cells = document.getElementsByClassName('cell');

//adds click events to cells and uses the alocated color
function addClickEventToCells() {
    for (var i = 0; i < cells.length; i++) {
        cells[i].addEventListener("click", function (event) {
            var clickedCell = event.target;
            clickedCell.style.backgroundColor = colorPicker.value;
        });
    }
}
// Select size input
function dimensions() {
    event.preventDefault();
    var height = document.getElementById('inputHeight').value;
    var width = document.getElementById('inputWidth').value;
    makeGrid(height, width);

}
//the dimesions are chosen according to the size chosen
document.getElementById('sizePicker').onsubmit = function () {
    dimensions();
};


// Grid created according to the dimesions inputted by the user
function makeGrid(y, x) {
    var table = document.getElementById("pixelCanvas");
    var grid = '';
    for (var i = 1; i <= y; i++) {
        grid += '<tr class="row-' + i + '">';
        for (var j = 1; j <= x; j++) {
            grid += '<td class="cell" id="row-' + i + '_cell-' + j + '"></td>';
        }
        grid += '</tr>';
    }
    table.innerHTML = grid;

    // click events added to grid
    addClickEventToCells();
}
